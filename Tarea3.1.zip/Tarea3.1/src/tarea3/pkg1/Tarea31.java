package tarea3.pkg1;

/**
 *
 * @author Erick Hernández
 */
public class Tarea31 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        //Se crean los nodo, todavia no es una lista enlazada
       Nodo primer = new Nodo("Ejemplo");
       Nodo segundo = new Nodo(45);
       Nodo tercer = new Nodo("Hola");
       
       //Se hace un enlace entre el primer y segundo nodo
       primer.enlazarSiguiente(segundo);
       //Se hace un enlace entre el segundo y tercer nodo, mediante el enlace del primer nodo con el segundo,
       //para eso se accede al método obtenerSiguiente de la clase Nodo.
       primer.obtenerSiguiente().enlazarSiguiente(tercer);
       
        //Ya es una lista enlazada
       //Se manda a pantalla el valor del primer nodo
        System.out.println(primer.obtenerValor());
         //Se manda a pantalla el valor del segundo nodo, mediante el enlace que tiene con el primer nodo
        System.out.println(primer.obtenerSiguiente().obtenerValor());
        //Se manda a pantalla el valor del tercer nodo, mediante el enlace que tiene con el segundo nodo
        System.out.println(segundo.obtenerSiguiente().obtenerValor());
    }
    
}
