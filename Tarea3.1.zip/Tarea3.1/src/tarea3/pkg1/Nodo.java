package tarea3.pkg1;

/**
 * 
 * @author Erick Hernández
 */
public class Nodo {

    // Variable en la cual se va a guardar el valor del nodo.
    Object  valor;
    // Variable para enlazar los nodos.
    Nodo siguiente;
    //Método constructor
    public Nodo(Object valor){
        this.valor = valor;
        this.siguiente = null;
    }
   
    //Te da el valor del nodo
    public Object obtenerValor(){
        return valor;
    }
    
    //Metodo que enlaza al siguiente nodo
    public void enlazarSiguiente(Nodo n){
        siguiente = n;
    }
    
    //Te regresa el enlace al siguiente nodo
    public Nodo obtenerSiguiente(){
        return siguiente;
    }
}
